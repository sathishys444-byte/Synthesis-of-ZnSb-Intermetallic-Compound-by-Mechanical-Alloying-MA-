# Synthesis of ZnSb Intermetallic Compound by Mechanical Alloying

**Powder Metallurgy Research | July 2025 – Present**

## Overview

This repository documents research on the synthesis and characterization of the ZnSb intermetallic compound produced via **Mechanical Alloying (MA)**, a solid-state powder processing technique. The goal is to develop ZnSb for advanced functional material applications (e.g. thermoelectric materials, where ZnSb-based compounds are of active interest) by controlling processing parameters to obtain the desired phase and microstructure.

## Key Highlights

- **Synthesis:** Produced ZnSb intermetallic compound using Mechanical Alloying, a high-energy ball milling technique that induces solid-state reactions between elemental Zn and Sb powders.
- **Characterization:**
  - **XRD (X-ray Diffraction):** Used to track phase formation and evolution, identify crystalline phases, and estimate crystallite size/strain across milling stages.
  - **SEM/EDS (Scanning Electron Microscopy / Energy-Dispersive X-ray Spectroscopy):** Used to examine microstructure, particle morphology, and elemental distribution/homogeneity.
- **Process–Structure–Property Analysis:** Correlated milling parameters (time, speed, ball-to-powder ratio) with phase evolution and resulting material properties to guide alloy development.

## Repository Structure

```
znsb-project/
├── README.md              # This file
├── LICENSE
├── requirements.txt        # Python dependencies for analysis scripts
├── data/                   # Raw / processed experimental data (XRD, EDS)
│   └── README.md
├── scripts/                 # Analysis scripts
│   ├── xrd_analysis.py     # XRD pattern plotting & peak analysis
│   └── sem_eds_analysis.py # EDS elemental composition summary/plots
├── figures/                # Generated plots and micrographs
└── docs/                   # Notes, references, methodology write-ups
    └── methodology.md
```

## Methodology (Summary)

1. **Powder Preparation:** Elemental Zn and Sb powders weighed in stoichiometric ratio.
2. **Mechanical Alloying:** High-energy ball milling performed under controlled atmosphere for defined durations to induce solid-state alloying.
3. **Phase Analysis (XRD):** Samples analyzed at different milling intervals to track the transition from elemental peaks to the ZnSb intermetallic phase.
4. **Microstructural Analysis (SEM/EDS):** Powder morphology and elemental distribution examined to assess homogeneity and particle refinement with milling time.
5. **Correlation:** Processing parameters mapped against phase purity and microstructural evolution.

See [`docs/methodology.md`](docs/methodology.md) for a more detailed write-up.

## Analysis Scripts

The `scripts/` folder contains starter Python scripts to help process and visualize your XRD and SEM/EDS data:

- `xrd_analysis.py` — loads a two-column (2θ, intensity) XRD data file, plots the diffraction pattern, and performs basic peak detection.
- `sem_eds_analysis.py` — loads an EDS elemental composition table (e.g. wt% or at% per element) and generates a summary bar chart.

Install dependencies with:

```bash
pip install -r requirements.txt
```

Then run, for example:

```bash
python scripts/xrd_analysis.py data/your_xrd_file.csv
```

## Status

🔬 **Active / Ongoing** — research started July 2025 and is currently in progress. This repository will be updated as new characterization results and analysis are completed.

## License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.
