"""
sem_eds_analysis.py

Loads an EDS elemental composition table and generates a summary bar chart,
plus basic homogeneity statistics across multiple point/spectrum measurements.

Expected input: a CSV with one row per measurement point/spectrum and one
column per element, e.g.:

    Spectrum,Zn (at%),Sb (at%)
    Spectrum 1,49.8,50.2
    Spectrum 2,50.5,49.5
    Spectrum 3,49.1,50.9

Usage:
    python sem_eds_analysis.py path/to/eds_data.csv
"""

import sys
import os
import pandas as pd
import matplotlib.pyplot as plt


def load_eds_data(filepath):
    df = pd.read_csv(filepath)
    return df


def summarize_composition(df):
    element_cols = [c for c in df.columns if c.lower() != "spectrum"]
    summary = df[element_cols].agg(["mean", "std", "min", "max"]).T
    return summary


def plot_composition(df, output_path=None):
    element_cols = [c for c in df.columns if c.lower() != "spectrum"]
    means = df[element_cols].mean()
    stds = df[element_cols].std()

    plt.figure(figsize=(7, 5))
    plt.bar(means.index, means.values, yerr=stds.values, capsize=5,
            color=["#4C72B0", "#DD8452", "#55A868", "#C44E52"][:len(means)])
    plt.ylabel("Composition (at% or wt%)")
    plt.title("Average Elemental Composition (EDS)")
    plt.tight_layout()

    if output_path:
        plt.savefig(output_path, dpi=200)
        print(f"Saved plot to {output_path}")
    else:
        plt.show()


def main():
    if len(sys.argv) < 2:
        print("Usage: python sem_eds_analysis.py path/to/eds_data.csv")
        sys.exit(1)

    filepath = sys.argv[1]
    if not os.path.exists(filepath):
        print(f"File not found: {filepath}")
        sys.exit(1)

    df = load_eds_data(filepath)
    summary = summarize_composition(df)

    print("EDS Composition Summary:")
    print(summary.round(2))

    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(filepath))), "figures")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "eds_composition.png")

    plot_composition(df, output_path=output_path)


if __name__ == "__main__":
    main()
