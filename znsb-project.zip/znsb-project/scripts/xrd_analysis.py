"""
xrd_analysis.py

Basic XRD pattern loader, plotter, and peak finder for ZnSb mechanical
alloying data.

Expected input: a CSV or whitespace-delimited text file with two columns:
    two_theta, intensity

Usage:
    python xrd_analysis.py path/to/xrd_data.csv
"""

import sys
import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks


def load_xrd_data(filepath):
    """Load two-column XRD data (2-theta, intensity)."""
    data = np.loadtxt(filepath, delimiter=None, skiprows=1)
    two_theta = data[:, 0]
    intensity = data[:, 1]
    return two_theta, intensity


def find_xrd_peaks(two_theta, intensity, prominence=None, distance=5):
    """Detect peaks in the XRD pattern.

    prominence: minimum peak prominence (defaults to 5% of max intensity)
    distance: minimum number of samples between peaks
    """
    if prominence is None:
        prominence = 0.05 * np.max(intensity)
    peak_indices, properties = find_peaks(
        intensity, prominence=prominence, distance=distance
    )
    return two_theta[peak_indices], intensity[peak_indices]


def plot_xrd(two_theta, intensity, peak_positions=None, peak_intensities=None,
             title="XRD Pattern", output_path=None):
    plt.figure(figsize=(9, 5))
    plt.plot(two_theta, intensity, linewidth=1, color="steelblue", label="XRD Pattern")

    if peak_positions is not None:
        plt.plot(peak_positions, peak_intensities, "rx", label="Detected Peaks")
        for x, y in zip(peak_positions, peak_intensities):
            plt.annotate(f"{x:.1f}", (x, y), textcoords="offset points",
                         xytext=(0, 8), ha="center", fontsize=8)

    plt.xlabel("2θ (degrees)")
    plt.ylabel("Intensity (a.u.)")
    plt.title(title)
    plt.legend()
    plt.tight_layout()

    if output_path:
        plt.savefig(output_path, dpi=200)
        print(f"Saved plot to {output_path}")
    else:
        plt.show()


def main():
    if len(sys.argv) < 2:
        print("Usage: python xrd_analysis.py path/to/xrd_data.csv")
        sys.exit(1)

    filepath = sys.argv[1]
    if not os.path.exists(filepath):
        print(f"File not found: {filepath}")
        sys.exit(1)

    two_theta, intensity = load_xrd_data(filepath)
    peak_pos, peak_int = find_xrd_peaks(two_theta, intensity)

    print(f"Loaded {len(two_theta)} data points.")
    print(f"Detected {len(peak_pos)} peaks at 2θ =")
    for p in peak_pos:
        print(f"  {p:.2f} degrees")

    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(filepath))), "figures")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "xrd_pattern.png")

    plot_xrd(two_theta, intensity, peak_pos, peak_int,
              title="ZnSb Mechanical Alloying - XRD Pattern",
              output_path=output_path)


if __name__ == "__main__":
    main()
