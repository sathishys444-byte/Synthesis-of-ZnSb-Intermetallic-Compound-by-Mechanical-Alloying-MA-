# Methodology Notes

## 1. Materials
- Elemental Zinc (Zn) powder
- Elemental Antimony (Sb) powder
- Mixed in stoichiometric ratio to target the ZnSb intermetallic composition

## 2. Mechanical Alloying (MA)
Mechanical alloying is a solid-state powder processing technique carried out in a high-energy ball mill. Repeated cold welding, fracturing, and re-welding of powder particles progressively refines the microstructure and promotes diffusion-driven alloying between the constituent elements.

Parameters typically tracked and reported:
- Ball-to-powder weight ratio (BPR)
- Milling speed (RPM)
- Milling time / intervals sampled
- Process control agent (PCA), if used
- Milling atmosphere (e.g. Ar to prevent oxidation)

## 3. Characterization Techniques

### X-ray Diffraction (XRD)
- Used to identify crystalline phases present at each milling stage.
- Peak positions confirm phase identity (matched against reference patterns, e.g. ICDD/JCPDS).
- Peak broadening analysis (e.g. Scherrer equation, Williamson–Hall) can be used to estimate crystallite size and lattice strain introduced by milling.
- Disappearance of elemental Zn/Sb peaks and emergence of ZnSb peaks indicates progression of alloying.

### SEM / EDS
- SEM imaging reveals particle morphology, size distribution, and agglomeration behavior as milling progresses.
- EDS mapping/point analysis confirms elemental distribution and homogeneity of Zn and Sb within particles, helping verify compositional uniformity.

## 4. Process–Structure–Property Correlation
Processing parameters (milling time, speed, BPR) are correlated against:
- Phase purity / completeness of alloying (from XRD)
- Microstructural refinement and homogeneity (from SEM/EDS)

This correlation supports optimization of processing conditions for consistent, high-quality ZnSb synthesis.

## References (add your sources here)
- [ ] Add relevant literature citations (e.g. papers on ZnSb thermoelectric properties, mechanical alloying reviews)
