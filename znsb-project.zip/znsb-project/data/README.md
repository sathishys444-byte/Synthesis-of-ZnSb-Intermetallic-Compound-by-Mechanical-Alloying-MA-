# Data

Place your raw and processed experimental data files here.

Suggested organization:

```
data/
├── xrd/
│   ├── as-milled_2h.csv
│   ├── as-milled_10h.csv
│   └── as-milled_20h.csv
└── eds/
    └── point_composition.csv
```

**XRD file format:** two columns — `2theta, intensity` (CSV or whitespace-delimited, one header row).

**EDS file format:** one row per spectrum/point, one column per element (at% or wt%), e.g.:

```
Spectrum,Zn (at%),Sb (at%)
Spectrum 1,49.8,50.2
Spectrum 2,50.5,49.5
```

> Note: Raw instrument data files can be large — consider adding a `.gitignore` entry or using Git LFS if your files exceed a few MB.
